#include"patchUrlmanager.h"

PatchUrlManager::PatchUrlManager(const char* cr): m_cr(cr)
{
	filename="inputfile/ALL_URL_"+m_cr+".txt";
	FILE* pf=fopen(filename.c_str(),"r+");

	if(!pf)
	{
		cout<<filename<<endl;
		puts("文件打开失败");
	}

	char buf[1024]={0};

	while(fgets(buf,sizeof(buf),pf))
	{
		//去掉换符号
		*strchr(buf,'\n')=0;
		m_purl.push_back(buf);
		cout<<buf<<endl;
		getPath(buf);
	}
}

void PatchUrlManager::showCr()
{

}

const string PatchUrlManager::getPath(string str)
{
	char buf[1024]={0};
	strcpy(buf,str.c_str());
	char* p1;
	char* p2;
	if(p1=strstr(buf,"https://source.codeaurora.org/"))
	{
		p1=p1+strlen("https://source.codeaurora.org/");
		if(p2=strstr(buf,"/patch"))
		{
			string path(p1,p2);
			cout<<path<<endl;
			return path; 
		}
	}	
}

void PatchUrlManager::showUrl()
{
	



}

void PatchUrlManager::downpatch()
{
	char cmd[1024]={0};
	for(auto it=m_purl.begin();it !=m_purl.end();it++)
	{
		string path="kerpatches/"+getPath(*it);
		sprintf(cmd,"wget -t2 -T15 -O %s/%s %s",path,it->c_str(),it->c_str());
		system(cmd);	
	}





}
