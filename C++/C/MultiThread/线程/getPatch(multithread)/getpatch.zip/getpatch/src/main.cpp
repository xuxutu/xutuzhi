#include "patchUrlmanager.h"
#include<iostream>
using namespace std;

int main(int argc,const char* argv[])
{

	PatchUrlManager pum(argv[1]);	
	pum.downpatch();

	return 0;
}
