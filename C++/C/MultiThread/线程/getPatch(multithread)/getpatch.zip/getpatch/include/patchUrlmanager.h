#ifndef __PATCHURLMANAGER__
#define	__PATCHURLMANAGER__
#include<iostream>
#include<string>
#include<vector>
#include<string>
#include<cstring>
using namespace std;
class PatchUrlManager
{
public:
	PatchUrlManager(const char* cr);//初始化cr
	void showCr();
	const string getPath(string str);
	void showUrl();
	void downpatch();

private:
	string m_cr;
	string filename;
	vector<string>m_purl;	
};

#endif
